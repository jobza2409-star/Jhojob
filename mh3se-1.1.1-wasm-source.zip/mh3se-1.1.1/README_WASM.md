# MH3SE browser/WASM port (work in progress)

This patch keeps the original MH3SE save parsing/writing code and replaces the web UI's
Axum HTTP calls with direct calls to a `wasm-bindgen` module.

## Build

Install Rust, add the WebAssembly target, and install `wasm-pack`:

```sh
rustup target add wasm32-unknown-unknown
cargo install wasm-pack
wasm-pack build --target web --release
```

The command should generate `pkg/mh3se.js` and `pkg/mh3se_bg.wasm` in the project root.
Those generated files are not included in this source archive; they must be produced by
the build command.

## Run locally

From the project root, run:

```sh
python -m http.server 8888
```

Open `http://localhost:8888/web/index.html`.

The `web/index.js` file dynamically imports `../pkg/mh3se.js`, preserving the existing
classic script and inline HTML event handlers. The original `web/database.json` is still
loaded from `/web/database.json`.

## Safety and test status

- The WASM wrapper calls the original `CharacterSlot::from_buf` and `save_write::write_slot`.
- The checksum calculation mirrors the existing `save_write::buf_to_file` implementation
  (sum bytes from offset 8 onward, write the big-endian `u32` at `CHECKSUM_OFFSET`).
- No real save file was supplied with this source archive, so no save round-trip or game
  load test has been performed here.
- This environment does not have `cargo`, `rustc`, or `wasm-pack`, so a WASM build could
  not be run here. Do not treat this patch as build-verified until the commands above pass.
- Always keep an untouched backup of the original `data00`/`data01` save files. Test a
  downloaded file by loading it again in the editor before using it in Dolphin.

## Important

This is a first implementation pass. It exposes the existing character-slot read/write
functions to JavaScript; it does not add new game data formats or prove that any custom
Charm values are accepted by the game. Charm constraints and the equipped-charm behavior
must be verified against the original save layout and game behavior.
