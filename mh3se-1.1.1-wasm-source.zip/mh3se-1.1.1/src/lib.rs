mod common;
mod save_read;
mod save_write;

use common::{CharacterSlot, CHECKSUM_OFFSET, SAVE_SIZE};
use wasm_bindgen::prelude::*;

/// Decode one character slot from an original MH3 save file into the JSON
/// representation already used by the project's web UI.
#[wasm_bindgen]
pub fn decode_save_to_json(save_bytes: &[u8], nth_slot: usize) -> Result<String, JsValue> {
    if save_bytes.len() != SAVE_SIZE {
        return Err(JsValue::from_str(&format!(
            "Invalid save file size: got {} bytes, expected {} bytes.",
            save_bytes.len(),
            SAVE_SIZE
        )));
    }
    if nth_slot > 2 {
        return Err(JsValue::from_str("Slot ranges from 0 to 2!"));
    }

    let mut buffer = [0u8; SAVE_SIZE];
    buffer.copy_from_slice(save_bytes);

    let slot = CharacterSlot::from_buf(&buffer, nth_slot)
        .map_err(|e| JsValue::from_str(&e))?;
    serde_json::to_string(&slot)
        .map_err(|e| JsValue::from_str(&format!("Failed to convert to JSON: {}", e)))
}

/// Write edited character data into a copy of the supplied original save file.
/// The checksum calculation intentionally mirrors save_write::buf_to_file.
#[wasm_bindgen]
pub fn encode_json_to_save(
    save_bytes: &[u8],
    json_str: &str,
    nth_slot: usize,
) -> Result<Vec<u8>, JsValue> {
    if save_bytes.len() != SAVE_SIZE {
        return Err(JsValue::from_str(&format!(
            "Invalid save file size: got {} bytes, expected {} bytes.",
            save_bytes.len(),
            SAVE_SIZE
        )));
    }
    if nth_slot > 2 {
        return Err(JsValue::from_str("Slot ranges from 0 to 2!"));
    }

    let slot: CharacterSlot = serde_json::from_str(json_str)
        .map_err(|e| JsValue::from_str(&format!("Failed to parse JSON slot: {}", e)))?;

    let mut buffer = [0u8; SAVE_SIZE];
    buffer.copy_from_slice(save_bytes);

    save_write::write_slot(&mut buffer, &slot, nth_slot)
        .map_err(|e| JsValue::from_str(&format!("Failed to write slot: {}", e)))?;

    // This is the same checksum algorithm used by the original native writer.
    let checksum: u32 = buffer.iter().skip(8).map(|&x| x as u32).sum();
    if SAVE_SIZE < CHECKSUM_OFFSET + 4 {
        return Err(JsValue::from_str("Invalid checksum offset"));
    }
    buffer[CHECKSUM_OFFSET..CHECKSUM_OFFSET + 4].copy_from_slice(&checksum.to_be_bytes());

    Ok(buffer.to_vec())
}
